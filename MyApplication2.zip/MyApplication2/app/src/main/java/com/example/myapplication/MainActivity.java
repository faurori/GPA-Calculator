package com.example.myapplication;

import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button button;
   // TextView GPAResults;
    double result;
    ScrollView mainLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.calculateGpa);

        mainLayout = (ScrollView) findViewById(R.id.mainLayout);

        EditText class1Grade = (EditText) findViewById(R.id.editText1);
        EditText class2Grade = (EditText) findViewById(R.id.editText2);
        EditText class3Grade = (EditText) findViewById(R.id.editText3);
        EditText class4Grade = (EditText) findViewById(R.id.editText4);
        EditText class5Grade = (EditText) findViewById(R.id.editText5);

        Spinner class1CreditsSpinner = (Spinner) findViewById(R.id.spinner1);
        Spinner class2CreditsSpinner = (Spinner) findViewById(R.id.spinner2);
        Spinner class3CreditsSpinner = (Spinner) findViewById(R.id.spinner3);
        Spinner class4CreditsSpinner = (Spinner) findViewById(R.id.spinner4);
        Spinner class5CreditsSpinner = (Spinner) findViewById(R.id.spinner5);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.credits));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        class1CreditsSpinner.setAdapter(myAdapter);
        class2CreditsSpinner.setAdapter(myAdapter);
        class3CreditsSpinner.setAdapter(myAdapter);
        class4CreditsSpinner.setAdapter(myAdapter);
        class5CreditsSpinner.setAdapter(myAdapter);

        button.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick (View view){



            EditText class1Grade = (EditText) findViewById(R.id.editText1);
            EditText class2Grade = (EditText) findViewById(R.id.editText2);
            EditText class3Grade = (EditText) findViewById(R.id.editText3);
            EditText class4Grade = (EditText) findViewById(R.id.editText4);
            EditText class5Grade = (EditText) findViewById(R.id.editText5);


            Spinner class1CreditsSpinner = (Spinner) findViewById(R.id.spinner1);
            Spinner class2CreditsSpinner = (Spinner) findViewById(R.id.spinner2);
            Spinner class3CreditsSpinner = (Spinner) findViewById(R.id.spinner3);
            Spinner class4CreditsSpinner = (Spinner) findViewById(R.id.spinner4);
            Spinner class5CreditsSpinner = (Spinner) findViewById(R.id.spinner5);

            String credit1 = String.valueOf(class1CreditsSpinner.getSelectedItem());
             int class1Credits = Integer.parseInt(credit1);
            String credit2 = String.valueOf(class2CreditsSpinner.getSelectedItem());
             int class2Credits = Integer.parseInt(credit2);
            String credit3 = String.valueOf(class3CreditsSpinner.getSelectedItem());
             int class3Credits = Integer.parseInt(credit3);
            String credit4 = String.valueOf(class4CreditsSpinner.getSelectedItem());
             int class4Credits = Integer.parseInt(credit4);
            String credit5 = String.valueOf(class5CreditsSpinner.getSelectedItem());
             int class5Credits = Integer.parseInt(credit5);



            double classGrade1 = 0.0;
            if (class1Grade.getText().toString() !="") {
                classGrade1 = Double.parseDouble(class1Grade.getText().toString());
            }

            double classGrade2 = 0.0;
            if (class2Grade.getText().toString() !=""){
                classGrade2 = Double.parseDouble(class2Grade.getText().toString());
            }

            double classGrade3 = 0.0;
            if (class3Grade.getText().toString() !=""){
                classGrade3 = Double.parseDouble(class3Grade.getText().toString());
            }
            double classGrade4 = 0.0;
            if (class4Grade.getText().toString() !=""){
                classGrade4 = Double.parseDouble(class4Grade.getText().toString());
            }

            double classGrade5 = 0.0;
            if (class5Grade.getText().toString() !=""){
                classGrade5 = Double.parseDouble(class5Grade.getText().toString());
            }

            double creditsTimesGrades1 = (class1Credits * classGrade1);
            double creditsTimesGrades2 = (class2Credits * classGrade2);
            double creditsTimesGrades3 = (class3Credits * classGrade3);
            double creditsTimesGrades4 = (class4Credits * classGrade4);
            double creditsTimesGrades5 = (class5Credits * classGrade5);

             int totalCredits = class1Credits + class2Credits + class3Credits + class4Credits + class5Credits;
             double creditsTimesGrades = creditsTimesGrades1 + creditsTimesGrades2 + creditsTimesGrades3 + creditsTimesGrades4 + creditsTimesGrades5;


            result = creditsTimesGrades / totalCredits;


            TextView GPAResults = (TextView) findViewById(R.id.GPAResults);

            GPAResults.setText(Double.toString(result));

            if (result <60 ) {
                mainLayout.setBackgroundColor(Color.RED);
            }else if (result >= 80){
                mainLayout.setBackgroundColor(Color.GREEN);
            }else{
                mainLayout.setBackgroundColor(Color.YELLOW);
        };





        };







    });
}}








